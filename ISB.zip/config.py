# Конфигурация ISB

# Ваш API ID от Telegram.
# Получить можно на https://my.telegram.org -> API Development Tools
api_id = 123456

# Ваш API Hash от Telegram.
# Получить можно на https://my.telegram.org -> API Development Tools
api_hash = "your_api_hash"